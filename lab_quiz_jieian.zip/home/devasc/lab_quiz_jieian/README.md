The purpose of this project is to demonstrate my proficiency in using Linux, Git, and Python.
